const config = require('./config.json');
const fs = require('fs');
const noblox = require('noblox.js'); noblox.setCookie(config.robloxconfig.session);
const Discord = require('discord.js');
const bot = new Discord.Client();

bot.on('ready', async () => {
    console.log('✅ Bot started.');
    bot.user.setActivity('.help | Omega Asylum Manager', { type: 'WATCHING' });
});

bot.on('message', async message => {

    if (message.author.bot) return;
    if (message.channel.type === 'dm') return;
    if (!message.content.startsWith(config.botconfig.prefix)) return;

    const args = message.content.slice(config.botconfig.prefix.length).trim().split(/ +/g);
    const command = args.shift().toLowerCase();

    try {
        let files = fs.readdirSync(__dirname + '/commands');

        for (let each of files) {
            if (each == command + '.js') {
                let commandFile = require(`./commands/${command}.js`);
                delete require.cache[require.resolve(`./commands/${command}.js`)];
                return commandFile.run(bot, message, args);
            }
        }
    } catch (err) {
        console.log(err);
    }
});

bot.login(config.botconfig.token);