const Discord = require('discord.js');
const config = require('../config.json');
const noblox = require('noblox.js');

module.exports.run = async (bot, message, args) => {
    if (!message.member.hasPermission('MANAGE_MESSAGES')) return;

    const getShout = await noblox.getShout(config.robloxconfig.maingroupid);
    const posterAvatar = await noblox.getPlayerThumbnail(getShout.poster.userId, 150);

    if (!args[0]) return message.channel.send('Options: `get` `set`');

    if (args[0] == 'get') {
        if (getShout.body.length == 0) return message.channel.send('The wall is empty.');
        
        const embed = new Discord.MessageEmbed()
            .setTitle('Shout: get')
            .setColor('#2F3136')
            .setThumbnail(posterAvatar[0].imageUrl)
            .addFields(
                { name: `Shout:`, value: `${getShout.body}` },
                { name: `Created at:`, value: `${getShout.created}` },
                { name: `Poster:`, value: `${getShout.poster.username} (${getShout.poster.userId})` }
            );

        message.channel.send(embed);
    };

    if (args[0] == 'set') {
        if (!args[1]) return message.channel.send('Arguments missing.');
        
        try {
            await noblox.shout(config.robloxconfig.maingroupid, args.slice(1).join(" "));

            message.channel.send('Success, ' + args.slice(1).join(" "));
        } catch (err) {
            return message.channel.send('Wrong usage, try again.');
        };
    };
}

module.exports.help = {
    name: "shout",
    description: "Group shout manager.",
    parameters: "(get, set(string))"
}