const Discord = require('discord.js');
const config = require('../config.json');
const noblox = require('noblox.js');

module.exports.run = async (bot, message, args) => {
    if (!message.member.hasPermission('MANAGE_MESSAGES')) return;

    if (!args[0]) return message.channel.send('Options: `get` `delete`');

    if (args[0] == 'get') {       
        const getWall = await noblox.getWall(config.robloxconfig.maingroupid);
        
        if (getWall.data.length == 0) return message.channel.send('The wall is empty.');
        
        const embedFields = [];

        for(i=0; i < getWall.data.length; i++) {
            embedFields[i] = {name: `${getWall.data[i].poster.user.username} (${getWall.data[i].poster.user.userId}) | ${getWall.data[i].id}`, value: `${getWall.data[i].body}`};
        };

        const embed = new Discord.MessageEmbed()
            .setTitle('Wall: get')
            .setColor('#2F3136')
            .setThumbnail(await noblox.getLogo(config.robloxconfig.maingroupid))
            .addFields(
                embedFields
            );

        message.channel.send(embed);
    };

    if (args[0] == 'delete') {
        if (!args[1]) return message.channel.send('Arguments missing.');

        try {
            if (args[1] == 'all') {
                const getWall = await noblox.getWall(config.robloxconfig.maingroupid);
                
                for (i=0; i < getWall.data.length; i++) {
                    await noblox.deleteWallPost(config.robloxconfig.maingroupid, getWall.data[i].id);
                };

                message.channel.send('Success.');
            } else {
                await noblox.deleteWallPost(config.robloxconfig.maingroupid, args[1]);
            
                message.channel.send('Success.');
            }
        } catch(err) {
            return message.channel.send('Wrong usage, try again.');
        };
    }
}

module.exports.help = {
    name: "wall",
    description: "Group wall manager.",
    parameters: "(get, delete((id, all)))"
}