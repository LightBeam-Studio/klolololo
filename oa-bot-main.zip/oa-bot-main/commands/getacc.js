const Discord = require('discord.js');
const config = require('../config.json');
const noblox = require('noblox.js');
const bloxLink = require('bloxlink.js');

module.exports.run = async (bot, message, args) => {
    if (!args[0]) return message.channel.send('Argument missing.');

    let userId = undefined;
    let usermention = message.mentions.users.first() || await bot.users.fetch(args[0]);

    const getUserId = await bloxLink.resolveID(usermention?.id)
        .then(data => userId = data)
        .catch(() => { });

    if (userId == undefined) return message.channel.send('The user is not linked to BloxLink.');

    let userInfo = await noblox.getPlayerInfo(userId);

    for (let each in userInfo) {
        if (userInfo[each] === '' || userInfo[each] == null || userInfo[each] == undefined || userInfo[each].length == 0) {
            userInfo[each] = 'none'
        }
    }

    let messageInfo = new Discord.MessageEmbed()
        .setTitle(`Roblox Account: ${usermention.tag}`)
        .setColor('#2F3136')
        .setDescription(`
    ▫ **Name/Id:** ${userInfo.username} (${userId})
    ▫ **Age:** ${userInfo.age}
    ▫ **Join date:** ${userInfo.joinDate}
    ▫ **Friends:** ${userInfo.friendCount}
    ▫ **Followers:** ${userInfo.followerCount}
    ▫ **Following:** ${userInfo.followingCount}
    ▫ **Is banned:** ${userInfo.isBanned}
    ▫ **Status:** ${userInfo.status}
    ▫ **Old names:** ${userInfo.oldNames}
    ▫ **Bio:**
    ${userInfo.blurb}
    `);

    if (userInfo.isBanned == true) {
        messageInfo = new Discord.MessageEmbed()
            .setTitle(`${userInfo.username}`)
            .setColor('#2F3136')
            .setDescription(`
    ▫ **Name/Id:** ${userInfo.username} (${userId})
    ▫ **Join date:** ${userInfo.joinDate}
    ▫ **Is banned:** ${userInfo.isBanned}
    ▫ **Bio:** 
    ${userInfo.blurb}
    `);
    }

    message.channel.send(messageInfo);
}

module.exports.help = {
    name: "getacc",
    description: "Gets an user roblox username/id.",
    parameters: "usermention"
}