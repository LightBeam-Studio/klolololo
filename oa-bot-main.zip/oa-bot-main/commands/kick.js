const Discord = require('discord.js');
const config = require('../config.json');
const noblox = require('noblox.js');

module.exports.run = async (bot, message, args) => {
    if (!message.member.hasPermission('MANAGE_MESSAGES')) return;

    if (!args[0]) return message.channel.send('Argument missing.');

    try {
        if (await noblox.getRankInGroup(config.robloxconfig.maingroupid, await noblox.getIdFromUsername(args[0])) == 0) return message.channel.send('Group member not found.');
        
        const userId = await noblox.getIdFromUsername(args[0]);

        await noblox.exile(config.robloxconfig.maingroupid, userId);

        message.channel.send(`Success, exiled: ${args[0]} (${userId})`)
    } catch (err) {
        return message.channel.send('Wrong usage, try again.');
    };
}

module.exports.help = {
    name: "kick",
    description: "Kicks a group member.",
    parameters: "Username"
}