const Discord = require('discord.js');
const config = require('../config.json');
const noblox = require('noblox.js');

module.exports.run = async (bot, message, args) => {
    if (!args[0]) return message.channel.send('Arguments missing.');

    try {
        if (await noblox.getRankInGroup(config.robloxconfig.maingroupid, await noblox.getIdFromUsername(args[0])) == 0) return message.channel.send('Group member not found.');

        const userId = await noblox.getIdFromUsername(args[0]);

        const roleName = await noblox.getRankNameInGroup(config.robloxconfig.maingroupid, userId);
        const roleNum = await noblox.getRankInGroup(config.robloxconfig.maingroupid, userId);

        message.channel.send(`Success, ${args[0]} rank: ${roleName} (${roleNum})`);
    } catch (err) {
        return message.channel.send('Wrong usage, try again.');
    };
}

module.exports.help = {
    name: "getrank",
    description: "Gets a player rank.",
    parameters: "Username"
}