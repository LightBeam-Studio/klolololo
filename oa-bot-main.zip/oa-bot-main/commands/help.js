const Discord = require('discord.js');
const fs = require('fs');

module.exports.run = async (bot, message, args) => {
    let dirfiles = fs.readdirSync(__dirname);

    let helpEmbed = new Discord.MessageEmbed()
        .setTitle('Helper')
        .setColor('#2F3136')
        .setAuthor(`${message.author.username}`, `${message.author.avatarURL({ dynamic: true, format: "png" })}`)
        .setThumbnail('https://cdn.discordapp.com/attachments/806915143501873183/807060907581898752/Png.png')
        .setDescription('Type ".help (command)" to get more info.')
        .addFields(
            { name: `Commands (${dirfiles.length}):`, value: `▫${dirfiles.sort().join('\n▫')}` }
        );

    if (args[0]) {
        try {
            let commandFile = require(`./${args[0]}`);

            let helpCommandEmbed = new Discord.MessageEmbed()
                .setTitle(commandFile.help.name)
                .setColor('#2F3136')
                .addFields(
                    { name: `Description:`, value: `${commandFile.help.description}` },
                    { name: `Parameters:`, value: `${commandFile.help.parameters}` },
                );

            message.channel.send(helpCommandEmbed)
        } catch {
            message.channel.send('Command not found.')
        }
    } else {
        message.channel.send(helpEmbed);
    }
}

module.exports.help = {
    name: "help",
    description: "you're dumb",
    parameters: "e"
}