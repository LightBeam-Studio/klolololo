const Discord = require('discord.js');
const config = require('../config.json');
const noblox = require('noblox.js');
const bloxLink = require('bloxlink.js');

module.exports.run = async (bot, message, args) => {
    if (!args[0]) return message.channel.send('Argument missing.');

    let userId = await noblox.getIdFromUsername(args[0])
        .catch(() => { });

    if (userId == undefined) return message.channel.send('The user does not exist.');

    let userInfo = await noblox.getPlayerInfo(userId);

    for (let each in userInfo) {
        if (userInfo[each] === '' || userInfo[each] == null || userInfo[each] == undefined || userInfo[each].length == 0) {
            userInfo[each] = 'none'
        }
    }

    let messageInfo = new Discord.MessageEmbed()
        .setTitle(`User info: ${userInfo.username} (${userId})`)
        .setColor('#2F3136')
        .setDescription(`
    ▫ **Name/Id:** ${userInfo.username} (${userId})
    ▫ **Age:** ${userInfo.age}
    ▫ **Join date:** ${userInfo.joinDate}
    ▫ **Friends:** ${userInfo.friendCount}
    ▫ **Followers:** ${userInfo.followerCount}
    ▫ **Following:** ${userInfo.followingCount}
    ▫ **Is banned:** ${userInfo.isBanned}
    ▫ **Status:** ${userInfo.status}
    ▫ **Old names:** ${userInfo.oldNames}
    ▫ **Bio:**
    ${userInfo.blurb}
    `);

    if (userInfo.isBanned == true) {
        messageInfo = new Discord.MessageEmbed()
            .setTitle(`${userInfo.username}`)
            .setColor('#2F3136')
            .setDescription(`
    ▫ **Name/Id:** ${userInfo.username} (${userId})
    ▫ **Join date:** ${userInfo.joinDate}
    ▫ **Is banned:** ${userInfo.isBanned}
    ▫ **Bio:** 
    ${userInfo.blurb}
    `);
    }

    message.channel.send(messageInfo);
}

module.exports.help = {
    name: "userinfo",
    description: "Gets an roblox user info.",
    parameters: "username"
}