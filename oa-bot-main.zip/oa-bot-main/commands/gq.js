const Discord = require('discord.js');
const config = require('../config.json');
const noblox = require('noblox.js');
const bloxLink = require('bloxlink.js');

module.exports.run = async (bot, message, args) => {
    if (!args[0]) return message.channel.send('Argument missing.');
    if (!args[1]) return message.channel.send('Argument missing.');
    
    let userId = await noblox.getIdFromUsername(args[0])
        .catch(() => { });

    if (userId == undefined) return message.channel.send('The user does not exist.');

    let userGroups = await noblox.getGroups(userId);

    let result = 'Not found.'
    for (i=0; i < userGroups.length; i++) {
        if (userGroups[i].Id == args[1]) {
            result = `**Found:** ${args[1]}`
        }
    }

    if (result != 'Not found.') {
        let getGroupInfo = await noblox.getGroup(args[1]);

        result += 
        `
        ▫ **Name/Id:** ${getGroupInfo.name} (${getGroupInfo.id})
        ▫ **Owner:** ${getGroupInfo.owner.username} (${getGroupInfo.owner.userId})
        ▫ **MemberCount:** ${getGroupInfo.memberCount}
        `
    }

    let messageGroups = new Discord.MessageEmbed()
        .setTitle(`Group Query: ${args[0]} (${userId})`)
        .setColor('#2F3136')
        .setDescription(`${result}`)
    
    message.channel.send(messageGroups);
}

module.exports.help = {
    name: "groupquery (gq)",
    description: "Looks if a user is in a group.",
    parameters: "username, groupid"
}