const Discord = require('discord.js');
const config = require('../config.json');
const noblox = require('noblox.js');

module.exports.run = async (bot, message, args) => {
    if (!message.member.hasPermission('MANAGE_MESSAGES')) return;

    let qlimit = 10
    if (args[0] == 10) { qlimit = args[0] };
    if (args[0] == 25) { qlimit = args[0] };

    const getLogs = await noblox.getAuditLog(config.robloxconfig.maingroupid, undefined, undefined, undefined, qlimit);
    const embedFields = [];

    for (i = 0; i < getLogs.data.length; i++) {
        embedFields[i] = { name: `${getLogs.data[i].actor.user.username} (${getLogs.data[i].actor.user.userId}) `, value: `${getLogs.data[i].actionType}` };
    };

    const embed = new Discord.MessageEmbed()
        .setTitle('Wall: get')
        .setColor('#2F3136')
        .setThumbnail(await noblox.getLogo(config.robloxconfig.maingroupid))
        .addFields(
            embedFields
        );

    message.channel.send(embed);
}

module.exports.help = {
    name: "logs",
    description: "Gets the group logs.",
    parameters: "Number<d: 10, 10-25>"
}