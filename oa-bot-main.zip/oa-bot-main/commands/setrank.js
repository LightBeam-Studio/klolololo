const Discord = require('discord.js');
const config = require('../config.json');
const noblox = require('noblox.js');

module.exports.run = async (bot, message, args) => {  
    if (!message.member.hasPermission('MANAGE_MESSAGES')) return;
    
    if (!args[0] || !args[1]) return message.channel.send('Arguments missing.');
    if (args[1] > 255 || args[1] < 1) return message.channel.send('Limit: 1-255');

    try {
        if (await noblox.getRankInGroup(config.robloxconfig.maingroupid, await noblox.getIdFromUsername(args[0])) == 0) return message.channel.send('Group member not found.');
        
        const userId = await noblox.getIdFromUsername(args[0]);

        await noblox.setRank(config.robloxconfig.maingroupid, userId, parseInt(args[1]));

        const roleName = await noblox.getRankNameInGroup(config.robloxconfig.maingroupid, userId);
        const roleNum = await noblox.getRankInGroup(config.robloxconfig.maingroupid, userId);

        message.channel.send(`Success, ${args[0]} (${userId}) new rank: ${roleName} (${roleNum})`)
    } catch (err) {
        return message.channel.send('Wrong usage, try again.');
    };
}

module.exports.help = {
    name: "setrank",
    description: "Sets a group member rank.",
    parameters: "Username, Rank<1-255>"
}