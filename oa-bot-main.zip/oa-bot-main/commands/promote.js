const Discord = require('discord.js');
const config = require('../config.json');
const noblox = require('noblox.js');

module.exports.run = async (bot, message, args) => {
    if (!message.member.hasPermission('MANAGE_MESSAGES')) return;

    if (!args[0]) return message.channel.send('Arguments missing.');

    let userId = await noblox.getIdFromUsername(args[0])
        .catch(() => { });

    if (userId == undefined) return message.channel.send('The user does not exist.');
    if (await noblox.getRankInGroup(config.robloxconfig.maingroupid, userId) == 0) return message.channel.send('The user is not in the group.');

    try {
        await noblox.promote(config.robloxconfig.maingroupid, userId);

        let roleName = await noblox.getRankNameInGroup(config.robloxconfig.maingroupid, userId);
        let roleNum = await noblox.getRankInGroup(config.robloxconfig.maingroupid, userId);

        message.channel.send(`Success, ${args[0]} (${userId}) new rank: ${roleName} (${roleNum})`);
    } catch {
        return message.channel.send('Impossible to promote the user.');
    }
}

module.exports.help = {
    name: "promote",
    description: "Promotes a group member.",
    parameters: "Username"
}